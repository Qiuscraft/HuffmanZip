#include "Counter.h"
#include <fstream>
#include <iostream>

std::map<char, int> Counter::getCountMap(const std::string& filename) {
	char character;
	std::ifstream inputFile(filename, std::ios::in);
	std::map<char, int> countMap;
	
	while (inputFile.get(character)) {
		countMap[character]++;
	}
	
	inputFile.close();

	return countMap;
}
