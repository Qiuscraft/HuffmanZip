#ifndef GUARD_Counter_h
#define GUARD_Counter_h

#include <map>
#include <string>

class Counter {
public:
	static std::map<char, int> getCountMap(const std::string& filename);
};

#endif

