#include "HuffmanTree.h"
#include <queue>

HuffmanTree::HuffmanTree(): root(nullptr) {}

HuffmanTree::HuffmanTree(const HuffmanTree &other) {
	if (other.root == nullptr)
		root = nullptr;
	else root = new HuffmanTreeNode(*other.root);
}

HuffmanTree::~HuffmanTree() {
	delete root;
}

HuffmanTree & HuffmanTree::operator=(const HuffmanTree &rhs) {
	if (&rhs != this) {
		delete root;
		if (rhs.root == nullptr)
			root = nullptr;
		else root = new HuffmanTreeNode(*rhs.root);
	}
	return *this;
}

HuffmanTree::HuffmanTree(HuffmanTreeNode *root): root(root) {}

HuffmanTree::HuffmanTree(const std::map<char, int> &m) {
	struct compare {
		bool operator()(HuffmanTreeNode *a, HuffmanTreeNode *b) {
			return *a > *b;
		}
	};
	std::priority_queue<HuffmanTreeNode *, std::vector<HuffmanTreeNode *>, compare> pri_queue;
	for (auto iter = m.begin(); iter != m.end(); iter ++) {
		HuffmanTreeNode *node = new HuffmanTreeNode(iter->first, iter->second);
		pri_queue.push(node);
	}
	
	while (pri_queue.size() > 1) {
		HuffmanTreeNode *node1 = pri_queue.top();
		pri_queue.pop();
		HuffmanTreeNode *node2 = pri_queue.top();
		pri_queue.pop();
		HuffmanTreeNode *parent = new HuffmanTreeNode('\0', node1->count + node2->count);
		parent->leftChild = node1;
		parent->rightChild = node2;
		pri_queue.push(parent);
	}
	
	root = pri_queue.top();
}


HuffmanTree::HuffmanTree(const std::string &s) {
	root = HuffmanTreeNode::deserialize(s);
}

std::string HuffmanTree::serialize() const {
	return HuffmanTreeNode::serialize(root);
}

HuffmanTree * HuffmanTree::deserialize(const std::string &s) {
	return new HuffmanTree(HuffmanTreeNode::deserialize(s));
}

std::map<std::string, char> HuffmanTree::getCharMap() const {
	std::map<std::string, char> m;
	HuffmanTreeNode::writeCharMap(root, "", m);
	return m;
}

std::map<char, std::string> HuffmanTree::getCodeMap() const {
	std::map<char, std::string> m;
	HuffmanTreeNode::writeCodeMap(root, "", m);
	return m;
}
