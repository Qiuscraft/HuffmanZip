#ifndef GUARD_HuffmanTree_h
#define GUARD_HuffmanTree_h

#include "HuffmanTreeNode.h"
#include <map>
#include <string>

class HuffmanTree {
public:
	HuffmanTreeNode *root;
	
	HuffmanTree();
	HuffmanTree(const HuffmanTree &other);
	~HuffmanTree();
	HuffmanTree & operator=(const HuffmanTree &rhs);
	
	HuffmanTree(HuffmanTreeNode *root);
	HuffmanTree(const std::map<char, int> &m);
	HuffmanTree(const std::string &s);
	
	std::string serialize() const;
	static HuffmanTree * deserialize(const std::string &s);

	std::map<std::string, char> getCharMap() const;
	std::map<char, std::string> getCodeMap() const;
};

#endif
