#include "HuffmanTreeNode.h"
#include <stdexcept>
#include <algorithm>
#include <sstream>

HuffmanTreeNode::HuffmanTreeNode():leftChild(nullptr), rightChild(nullptr), data('\0'), count(0) {}

HuffmanTreeNode::HuffmanTreeNode(const HuffmanTreeNode &other): data(other.data), count(other.count) {
	if (other.leftChild != nullptr)
		leftChild = new HuffmanTreeNode(*other.leftChild);
	if (other.rightChild != nullptr)
		rightChild = new HuffmanTreeNode(*other.rightChild);
}

HuffmanTreeNode::~HuffmanTreeNode() {
	delete leftChild, rightChild;
}

HuffmanTreeNode & HuffmanTreeNode::operator=(const HuffmanTreeNode &rhs) {
	if (&rhs != this) {
		delete leftChild, rightChild;
		data = rhs.data;
		count = rhs.count;
		if (rhs.leftChild != nullptr)
			leftChild = new HuffmanTreeNode(*rhs.leftChild);
		if (rhs.rightChild != nullptr)
			rightChild = new HuffmanTreeNode(*rhs.rightChild);
	}
	return *this;
}

HuffmanTreeNode::HuffmanTreeNode(char data, int count): data(data), leftChild(nullptr), rightChild(nullptr), count(count) {}

HuffmanTreeNode::HuffmanTreeNode(char data, int count, HuffmanTreeNode *leftChild, HuffmanTreeNode *rightChild): data(data), count(count), leftChild(leftChild), rightChild(rightChild) {}

HuffmanTreeNode::HuffmanTreeNode(const std::string &s) {
	if (s[0] != '(')
		throw std::domain_error("Invalid input when deserializing HuffmanTreeNode.");
	if (s[1] == ')')
		throw std::domain_error("Trying to construct a Null HuffmanTreeNode.");
	
	data = s[1] == ','? '\0': s[1];
	count = extractNumberBetweenCommas(s);
	std::string left_s = extractIthParenthese(s.substr(4), 1);
	std::string right_s = extractIthParenthese(s.substr(4), 2);
	leftChild = deserialize(left_s);
	rightChild = deserialize(right_s);
}

bool HuffmanTreeNode::operator<(const HuffmanTreeNode &other) const {
	return count < other.count;
}

bool HuffmanTreeNode::operator>(const HuffmanTreeNode &other) const {
	return count > other.count;
}

bool HuffmanTreeNode::operator==(const HuffmanTreeNode &other) const {
	return count == other.count;
}

bool HuffmanTreeNode::operator<=(const HuffmanTreeNode &other) const {
	return count <= other.count;
}

bool HuffmanTreeNode::operator>=(const HuffmanTreeNode &other) const {
	return count >= other.count;
}

std::string HuffmanTreeNode::serialize() const {
	std::string data_s = std::string(1, data);
	if (data == '(' || data == ')' || data == '\\')
		data_s = '\\' + data_s;
	return "(" + data_s + "," + std::to_string(count) + "," + serialize(leftChild) + "," + serialize(rightChild) + ")";
}

std::string HuffmanTreeNode::serialize(HuffmanTreeNode *node) {
	if (node == nullptr)
		return "()";
	return node->serialize();
}

HuffmanTreeNode * HuffmanTreeNode::deserialize(const std::string &s) {
	if (s[0] != '(')
		throw std::domain_error("Invalid input when deserializing HuffmanTreeNode.");
	if (s[1] == ')')
		return nullptr;
	
	char data;
	if (s[1] == ',')
		data = '\0';
	else if (s[1] == '\\')
		data = s[2];
	else data = s[1];

	int count = extractNumberBetweenCommas(s);
	std::string left_s = extractIthParenthese(s.substr(4), 1);
	std::string right_s = extractIthParenthese(s.substr(4), 2);
	return new HuffmanTreeNode(data, count, deserialize(left_s), deserialize(right_s));
}

int extractNumberBetweenCommas(const std::string& input) {
    size_t firstComma = input.find(',');
    if (firstComma == std::string::npos) {
        throw std::domain_error("First comma not found.");
    }

    size_t secondComma = input.find(',', firstComma + 1);
    if (secondComma == std::string::npos) {
        throw std::domain_error("Second comma not found.");
    }

    std::string numberStr = input.substr(firstComma + 1, secondComma - firstComma - 1);
    std::istringstream numberStream(numberStr);
    int result;
    if (!(numberStream >> result)) {
        throw std::domain_error("Failed to convert the string between commas to an integer.");
    }

    return result;
}

std::string extractIthParenthese(const std::string& str, int i) {
	std::string result;
	int count = 1;
	int pare_count = 0;
	bool recording = false;
	for (size_t j = 0; j < str.size(); j++) {
		bool flag = j == 0 || str[j - 1] != '\\';
		if (flag) {
			if (str[j] == '(') {
				pare_count ++;
				if (count == i)
					recording = true;
			}
			if (str[j] == ')') {
				pare_count --;
				if (pare_count == 0) {
					if (recording) {
						result += str[j];
						return result;
					}
					count ++;
				}
			}
		}
		if (recording)
			result += str[j];
	}
	throw std::domain_error("Cannot find " + std::to_string(i) + "th parenthese.");
}

std::map<std::string, char> & HuffmanTreeNode::writeCharMap(const HuffmanTreeNode *node, std::string s, std::map<std::string, char> &m) {
	if (node == nullptr)
		return m;
	
	if (node->data != '\0')
		m[s] = node->data;

	else {
		writeCharMap(node->leftChild, s + "0", m);
		writeCharMap(node->rightChild, s + "1", m);
	}

	return m;
}

std::map<char, std::string> & HuffmanTreeNode::writeCodeMap(const HuffmanTreeNode *node, std::string s, std::map<char, std::string> &m) {
	if (node == nullptr)
		return m;
	
	if (node->data != '\0')
		m[node->data] = s;

	else {
		writeCodeMap(node->leftChild, s + "0", m);
		writeCodeMap(node->rightChild, s + "1", m);
	}

	return m;
}
