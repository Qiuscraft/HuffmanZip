#ifndef GUARD_HuffmanTreeNode_h
#define GUARD_HuffmanTreeNode_h

#include <string>
#include <map>

class HuffmanTreeNode {
public:
	char data;
	HuffmanTreeNode *leftChild, *rightChild;
    int count;

	HuffmanTreeNode();
	HuffmanTreeNode(const HuffmanTreeNode &other);
	~HuffmanTreeNode();
	HuffmanTreeNode & operator=(const HuffmanTreeNode &rhs);

    HuffmanTreeNode(char data, int count);
    HuffmanTreeNode(char data, int count, HuffmanTreeNode *leftChild, HuffmanTreeNode *rightChild);
	HuffmanTreeNode(const std::string &s);
	
	bool operator<(const HuffmanTreeNode &other) const;
	bool operator>(const HuffmanTreeNode &other) const;
	bool operator==(const HuffmanTreeNode &other) const;
	bool operator<=(const HuffmanTreeNode &other) const;
	bool operator>=(const HuffmanTreeNode &other) const;

	std::string serialize() const;
	static std::string serialize(HuffmanTreeNode *node);
	static HuffmanTreeNode * deserialize(const std::string &s);
	static std::map<std::string, char> & writeCharMap(const HuffmanTreeNode *node, std::string s, std::map<std::string, char> &m);
	static std::map<char, std::string> & writeCodeMap(const HuffmanTreeNode *node, std::string s, std::map<char, std::string> &m);
};

int extractNumberBetweenCommas(const std::string& input);
std::string extractIthParenthese(const std::string& str, int i);

#endif
