#include <winsock2.h>
#include "HuffmanZip.h"
#include "Counter.h"
#include "HuffmanTree.h"
#include <fstream>
#include <stdexcept>
#include <bitset>
#include <sstream>
#include <cstdint>

void HuffmanZip::compress(const std::string& inputPath, const std::string& outputPath) {
    std::map<char, int> countMap = Counter::getCountMap(inputPath);
    HuffmanTree huffmanTree(countMap);
    std::map<char, std::string> codeMap = huffmanTree.getCodeMap();

    std::ifstream inFile(inputPath, std::ios::binary);
    std::ofstream outFile(outputPath, std::ios::binary);

    std::string serializedTree = huffmanTree.serialize();
    uint32_t treeSize = serializedTree.size();

    treeSize = htonl(treeSize);
    outFile.write(reinterpret_cast<char*>(&treeSize), sizeof(treeSize));

    outFile.write(serializedTree.c_str(), serializedTree.size());

    std::string bitStream;
    char ch;
    while (inFile.get(ch)) {
        bitStream += codeMap[ch];
    }

    size_t padding = 8 - (bitStream.size() % 8);
    if (padding != 8) {
        bitStream.append(padding, '0');
    } else {
        padding = 0;
    }

    outFile.put(static_cast<char>(padding));

    for (size_t i = 0; i < bitStream.size(); i += 8) {
        std::bitset<8> bits(bitStream.substr(i, 8));
        char byte = static_cast<char>(bits.to_ulong());
        outFile.put(byte);
    }

    inFile.close();
    outFile.close();
}

void HuffmanZip::decompress(const std::string& inputPath, const std::string& outputPath) {
    std::ifstream inFile(inputPath, std::ios::binary);
    if (!inFile)
        throw std::domain_error("Unable to open input file.");

    uint32_t treeSize;
    inFile.read(reinterpret_cast<char*>(&treeSize), sizeof(treeSize));
    treeSize = ntohl(treeSize);

    std::string serializedTree(treeSize, '\0');
    inFile.read(&serializedTree[0], treeSize);
    HuffmanTree tree = HuffmanTree(serializedTree);
    HuffmanTreeNode* root = tree.root;

    char paddingChar;
    inFile.get(paddingChar);
    size_t padding = static_cast<unsigned char>(paddingChar);

    std::string bitStream;
    char ch;
    while (inFile.get(ch)) {
        std::bitset<8> bits(static_cast<unsigned long long>(static_cast<unsigned char>(ch)));
        bitStream += bits.to_string();
    }

    if (padding > 0 && padding < 8) {
        bitStream = bitStream.substr(0, bitStream.size() - padding);
    }

    std::ofstream outFile(outputPath, std::ios::out | std::ios::binary);
    if (!outFile)
        throw std::domain_error("Unable to open output file.");

    HuffmanTreeNode* currentNode = root;
    for (char bit : bitStream) {
        currentNode = (bit == '0') ? currentNode->leftChild : currentNode->rightChild;

        if (!currentNode->leftChild && !currentNode->rightChild) {
            outFile.put(currentNode->data);
            currentNode = root;
        }
    }

    inFile.close();
    outFile.close();
}
