#include "Counter.h"
#include "HuffmanTree.h"
#include "HuffmanZip.h"
#include <map>
#include <iostream>
#include <string>

int main() {
    std::map<char, int> m = Counter::getCountMap("input.txt");
    for (auto iter = m.begin(); iter !=m.end(); iter++)
        std::cout << iter->first << ": " << iter->second << std::endl;
    HuffmanTree tree = HuffmanTree(m);
    std::cout << tree.serialize() << std::endl;
    std::cout << std::endl;
    
    std::cout << HuffmanTree(tree.serialize()).serialize() << std:: endl;
    std::cout << std::endl;

    std::map<std::string, char> charMap = tree.getCharMap();
    for (auto iter = charMap.begin(); iter != charMap.end(); iter++)
        std::cout << iter->first << ": " << iter->second << std::endl;

    HuffmanZip::compress("input.txt", "output.huffman");
    HuffmanZip::decompress("output.huffman", "decompressed.txt");

    return 0;
}
